import { NextRequest, NextResponse } from 'next/server';
import { getSquareClient } from '@/lib/square';
import { CreatePaymentRequest } from 'squareup';

export async function POST(request: NextRequest) {
  try {
    const { sourceId, orderId, orderVersion, amount } = await request.json();

    if (!sourceId || !orderId || !amount) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const client = getSquareClient();
    const locationId = process.env.NEXT_PUBLIC_SQUARE_LOCATION_ID;

    if (!locationId) {
      return NextResponse.json(
        { error: 'Square location ID not configured' },
        { status: 500 }
      );
    }

    // Create payment
    const paymentRequest: CreatePaymentRequest = {
      sourceId: sourceId,
      orderId: orderId,
      idempotencyKey: `${orderId}-${Date.now()}`,
      amountMoney: {
        amount: amount,
        currency: 'USD',
      },
    };

    const { result } = await client.paymentsApi.createPayment(paymentRequest);

    if (result.payment?.status === 'APPROVED' || result.payment?.status === 'COMPLETED') {
      return NextResponse.json({
        success: true,
        paymentId: result.payment?.id,
      });
    } else {
      return NextResponse.json(
        { 
          success: false, 
          error: result.payment?.status || 'Payment not approved' 
        },
        { status: 400 }
      );
    }
  } catch (error: any) {
    console.error('Error processing payment:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Payment failed' },
      { status: 500 }
    );
  }
}

