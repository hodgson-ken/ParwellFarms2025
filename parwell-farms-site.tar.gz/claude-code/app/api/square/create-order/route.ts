import { NextRequest, NextResponse } from 'next/server';
import { getSquareClient } from '@/lib/square';
import { CreateOrderRequest } from 'squareup';

export async function POST(request: NextRequest) {
  try {
    const { itemVariationId, quantity } = await request.json();

    if (!itemVariationId || !quantity) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const client = getSquareClient();
    const locationId = process.env.NEXT_PUBLIC_SQUARE_LOCATION_ID;

    if (!locationId) {
      return NextResponse.json(
        { error: 'Square location ID not configured' },
        { status: 500 }
      );
    }

    // Create order
    const orderRequest: CreateOrderRequest = {
      order: {
        locationId: locationId,
        lineItems: [
          {
            quantity: quantity.toString(),
            catalogObjectId: itemVariationId,
            catalogVersion: undefined,
          },
        ],
      },
    };

    const { result } = await client.ordersApi.createOrder(orderRequest);

    return NextResponse.json({
      orderId: result.order?.id,
      orderVersion: result.order?.version,
    });
  } catch (error: any) {
    console.error('Error creating order:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to create order' },
      { status: 500 }
    );
  }
}

