import { NextRequest, NextResponse } from 'next/server';
import { getSquareClient } from '@/lib/square';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const client = getSquareClient();
    const { result } = await client.catalogApi.retrieveCatalogObject(params.id, false);
    
    if (result.object?.imageData?.url) {
      // Redirect to Square's image URL
      return NextResponse.redirect(result.object.imageData.url);
    }
    
    // Return 404 if no image
    return NextResponse.json({ error: 'Image not found' }, { status: 404 });
  } catch (error) {
    console.error('Error fetching Square image:', error);
    return NextResponse.json({ error: 'Failed to fetch image' }, { status: 500 });
  }
}

