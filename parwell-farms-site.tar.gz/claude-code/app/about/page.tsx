export default function AboutPage() {
  return (
    <div className="py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-serif font-bold text-farm-green mb-8 text-center">
          About Parwell Farms
        </h1>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12">
            <h2 className="text-3xl font-serif font-bold text-farm-green mb-4">
              Our Story
            </h2>
            <p className="text-gray-700 mb-4">
              At Parwell Farms, we take pride in cultivating the finest lavender and creating 
              handcrafted products that bring the essence of our farm to your home. Our journey 
              began with a passion for natural, high-quality goods made with care and dedication.
            </p>
            <p className="text-gray-700">
              We believe in sustainable farming practices and the power of natural ingredients. 
              Every product we create is thoughtfully crafted to bring you the best of what 
              our farm has to offer.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-3xl font-serif font-bold text-farm-green mb-4">
              Our Products
            </h2>
            <p className="text-gray-700 mb-4">
              From our own lavender fields, we create a wide range of products including:
            </p>
            <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
              <li>Handcrafted soaps and lotions</li>
              <li>Premium lavender products</li>
              <li>Healing salves and balms</li>
              <li>Moisturizing chapstick</li>
              <li>Farm-themed apparel and home goods</li>
              <li>Unique gifts and accessories</li>
            </ul>
            <p className="text-gray-700">
              Each product is made with the highest quality ingredients and attention to detail, 
              ensuring you receive items that are both beautiful and functional.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-3xl font-serif font-bold text-farm-green mb-4">
              Our Commitment
            </h2>
            <p className="text-gray-700 mb-4">
              We are committed to providing our customers with exceptional products and service. 
              Whether you're shopping for yourself or looking for the perfect gift, we strive to 
              make your experience with Parwell Farms enjoyable and memorable.
            </p>
            <p className="text-gray-700">
              Thank you for supporting local farming and handcrafted goods. We're grateful to 
              share our farm's bounty with you.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

