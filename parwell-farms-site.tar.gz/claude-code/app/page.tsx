import Link from 'next/link';
import { getSquareItems } from '@/lib/square';
import ProductCard from '@/components/ProductCard';

export default async function HomePage() {
  // Fetch featured products from Square
  const allItems = await getSquareItems();
  const featuredProducts = allItems.slice(0, 6); // Show 6 featured products

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-lavender-100 via-farm-cream to-green-50 py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-serif font-bold text-farm-green mb-6">
            Welcome to Parwell Farms
          </h1>
          <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
            Premium farm products and handcrafted goods made with care. 
            From our lavender fields to your home, experience the finest quality products.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/products" className="btn-primary inline-block">
              Shop Now
            </Link>
            <Link href="/about" className="btn-secondary inline-block">
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      {featuredProducts.length > 0 && (
        <section className="py-16 px-4">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl font-serif font-bold text-center text-farm-green mb-12">
              Featured Products
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProducts.map((item) => (
                <ProductCard key={item.id} item={item} />
              ))}
            </div>
            <div className="text-center mt-12">
              <Link href="/products" className="btn-primary">
                View All Products
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* About Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-serif font-bold text-farm-green mb-6">
            About Parwell Farms
          </h2>
          <p className="text-lg text-gray-700 mb-4">
            At Parwell Farms, we take pride in cultivating the finest lavender and creating 
            handcrafted products that bring the essence of our farm to your home. Our journey 
            began with a passion for natural, high-quality goods made with care and dedication.
          </p>
          <p className="text-lg text-gray-700 mb-8">
            From our own lavender fields, we create a wide range of products including soaps, 
            lotions, salves, balms, chapstick, and more. We also offer themed products like 
            t-shirts, sweatshirts, butter dishes, and signs that celebrate farm life.
          </p>
          <Link href="/about" className="btn-secondary">
            Learn More About Us
          </Link>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-green-50 to-lavender-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-serif font-bold text-center text-farm-green mb-12">
            Shop by Category
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { name: 'Soaps', href: '/products?category=soaps' },
              { name: 'Lotions', href: '/products?category=lotions' },
              { name: 'Lavender', href: '/products?category=lavender' },
              { name: 'Salves & Balms', href: '/products?category=salves' },
              { name: 'Chapstick', href: '/products?category=chapstick' },
              { name: 'Apparel', href: '/products?category=apparel' },
              { name: 'Home Goods', href: '/products?category=home' },
              { name: 'Gifts', href: '/products?category=gifts' },
            ].map((category) => (
              <Link
                key={category.name}
                href={category.href}
                className="card p-6 text-center hover:scale-105 transition-transform"
              >
                <h3 className="text-xl font-serif font-semibold text-farm-green">
                  {category.name}
                </h3>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

