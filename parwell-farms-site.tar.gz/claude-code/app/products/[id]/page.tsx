import { getSquareItemById } from '@/lib/square';
import { formatPrice, getItemVariations } from '@/lib/square';
import SquareCheckout from '@/components/SquareCheckout';
import { notFound } from 'next/navigation';

interface ProductDetailPageProps {
  params: { id: string };
}

export default async function ProductDetailPage({ params }: ProductDetailPageProps) {
  const item = await getSquareItemById(params.id);
  
  if (!item || !item.itemData) {
    notFound();
  }

  const variations = getItemVariations(item);
  const imageId = item.itemData.imageIds?.[0];
  const imageUrl = imageId 
    ? `/api/square/image/${imageId}` 
    : '/placeholder-product.jpg';

  return (
    <div className="py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="aspect-square overflow-hidden rounded-lg bg-gray-100">
            <img
              src={imageUrl}
              alt={item.itemData.name || 'Product'}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/placeholder-product.jpg';
              }}
            />
          </div>

          {/* Product Info */}
          <div>
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-farm-green mb-4">
              {item.itemData.name}
            </h1>
            
            {variations.length > 0 && variations[0].price && (
              <div className="text-3xl font-bold text-lavender-600 mb-6">
                {formatPrice(variations[0].price)}
              </div>
            )}

            {item.itemData.description && (
              <div className="mb-8">
                <h2 className="text-xl font-serif font-semibold text-farm-green mb-3">
                  Description
                </h2>
                <p className="text-gray-700 whitespace-pre-line">
                  {item.itemData.description}
                </p>
              </div>
            )}

            {/* Product Variations */}
            <div className="mb-8">
              <h2 className="text-xl font-serif font-semibold text-farm-green mb-3">
                Select Option
              </h2>
              {variations.length > 0 ? (
                <SquareCheckout 
                  item={item} 
                  variations={variations}
                />
              ) : (
                <p className="text-gray-600">This product is currently unavailable.</p>
              )}
            </div>

            {/* Additional Info */}
            {item.itemData.taxIds && item.itemData.taxIds.length > 0 && (
              <div className="border-t pt-6 mt-6">
                <p className="text-sm text-gray-600">
                  Tax may apply. Final price calculated at checkout.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

