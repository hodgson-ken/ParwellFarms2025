import { Client, Environment, ApiError } from 'square';

// Initialize Square client
export function getSquareClient() {
  const accessToken = process.env.SQUARE_ACCESS_TOKEN;
  const environment = process.env.SQUARE_ENVIRONMENT === 'production' 
    ? Environment.Production 
    : Environment.Sandbox;

  if (!accessToken) {
    throw new Error('SQUARE_ACCESS_TOKEN is not set');
  }

  return new Client({
    accessToken,
    environment,
  });
}

// Fetch all items from Square Catalog
export async function getSquareItems() {
  try {
    const client = getSquareClient();
    const { result } = await client.catalogApi.searchCatalogItems({
      limit: 100,
    });

    // Filter to only return ITEM type objects
    const items = result.items?.filter((item: any) => item.type === 'ITEM') || [];
    return items;
  } catch (error) {
    console.error('Error fetching Square items:', error);
    if (error instanceof ApiError) {
      console.error('Square API Error:', error.errors);
    }
    return [];
  }
}

// Fetch a single item by ID
export async function getSquareItemById(itemId: string) {
  try {
    const client = getSquareClient();
    const { result } = await client.catalogApi.retrieveCatalogObject(itemId, true);
    
    return result.object || null;
  } catch (error) {
    console.error('Error fetching Square item:', error);
    return null;
  }
}

// Get item variations with pricing
export function getItemVariations(item: any) {
  if (!item.itemData?.variations) return [];
  
  return item.itemData.variations.map((variation: any) => ({
    id: variation.id,
    name: variation.itemVariationData?.name || 'Default',
    price: variation.itemVariationData?.priceMoney 
      ? {
          amount: variation.itemVariationData.priceMoney.amount,
          currency: variation.itemVariationData.priceMoney.currency,
        }
      : null,
    sku: variation.itemVariationData?.sku,
    available: variation.itemVariationData?.trackInventory !== false,
  }));
}

// Format price for display
export function formatPrice(price: { amount: number; currency: string } | null) {
  if (!price) return 'Price not available';
  
  const amount = price.amount / 100; // Square stores amounts in cents
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: price.currency || 'USD',
  }).format(amount);
}

