import Link from 'next/link';
import { formatPrice, getItemVariations } from '@/lib/square';

interface ProductCardProps {
  item: any;
}

export default function ProductCard({ item }: ProductCardProps) {
  const variations = getItemVariations(item);
  const firstVariation = variations[0];
  const price = firstVariation?.price;
  // Square images need to be retrieved via API
  // For now, use placeholder or fetch via Square API endpoint
  const imageId = item.itemData?.imageIds?.[0];
  const imageUrl = imageId 
    ? `/api/square/image/${imageId}` 
    : '/placeholder-product.jpg';

  return (
    <Link href={`/products/${item.id}`} className="card group">
      <div className="aspect-square overflow-hidden bg-gray-100">
        <img
          src={imageUrl}
          alt={item.itemData?.name || 'Product'}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          onError={(e) => {
            (e.target as HTMLImageElement).src = '/placeholder-product.jpg';
          }}
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-serif font-semibold text-farm-green mb-2 group-hover:text-lavender-600 transition-colors">
          {item.itemData?.name || 'Product'}
        </h3>
        {item.itemData?.description && (
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">
            {item.itemData.description}
          </p>
        )}
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-farm-green">
            {formatPrice(price)}
          </span>
          {variations.length > 1 && (
            <span className="text-sm text-gray-500">
              {variations.length} variants
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}

